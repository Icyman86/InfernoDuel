INFERNO DUEL: LEGENDS — Linux fighter expansion v0.3
Made by Rens de Gee en Ted Sondervan

Run ./PLAY.sh on a Linux x86_64 desktop with OpenGL 3.3 support.
This build bundles the Godot engine and a game PCK. No installed Godot is required.

P1: A/D move, W jump, S block, F light, G heavy, H special, J ultimate.
P2: arrows move/jump/block, I light, O heavy, P special, L ultimate.
ESC pauses. F3 displays hitboxes. Win two rounds to win a match.
Select: P1 WASD + F ready / G undo. P2 arrows + I ready / O undo.
Mouse: choose the P1/P2 edit button before clicking a fighter.

Five playable fighters: SharkByte, Bullet, PoisonBoy, Chainveil and Cheese Rat.
PoisonBoy casts Toxic Splash / Venom Cataclysm. Chainveil's Chain Lash and Iron
Widow have extended range and pull targets. Cheese Rat throws Cheese Ball;
hold backward plus special for Cheese Trap. Ultimate: King of the Cheese.
Five other roster fighters remain in development.
FIGHTERS has individual sheets and a PLAY INTRO button for all ten characters.
Each short intro opens on footwear (original claws for Crystal Fang/Phoenix
Reign), then a front kick toward camera. REPLAY restarts; Esc/BACK returns.
Original reference sheets are preserved. New sprite/intro art is reference-guided.
Story, expanded movesets, music and Android are later milestones.
Two-person physical keyboard / ghosting testing is still required.

Engine package: official Linux release template 4.6.3.stable.official.7d41c59c4
