INFERNO DUEL: LEGENDS — Linux visual build v0.2
Made by Rens de Gee en Ted Sondervan

Run ./PLAY.sh on a Linux x86_64 desktop with OpenGL 3.3 support.
This build bundles the unmodified Godot 4.6.3 editor engine and a game PCK,
not a stripped release-template executable. No installed Godot is required.

P1: A/D move, W jump, S block, F light, G heavy, H special, J ultimate.
P2: arrows move/jump/block, I light, O heavy, P special, L ultimate.
ESC pauses. F3 displays hitboxes. Win two rounds to win a match.
Select: P1 WASD + F ready / G undo. P2 arrows + I ready / O undo.
Mouse: choose the P1/P2 edit button before clicking a fighter.

SharkByte and Bullet have reference-derived illustrated sprite animation sets.
All ten roster slots have original-sheet avatars; eight fighters are coming soon.
The citadel, menus and HUD have new artwork. Original reference sheets remain
unaltered in the gallery. Sprite keyframes were generated from those references.
Story, expanded movesets, music and Android are later milestones.
Two-person physical keyboard / ghosting testing is still required.
